plugins { id("com.android.application") }

android {
    namespace = "com.nosrafarm.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nosrafarm.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "1.5.0"
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("nosra-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
