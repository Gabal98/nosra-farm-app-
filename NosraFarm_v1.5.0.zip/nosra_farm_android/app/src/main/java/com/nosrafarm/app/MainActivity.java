package com.nosrafarm.app;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.os.Build;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean captureInProgress = false;
    private static final int REQ_CREATE_BACKUP = 4101;
    private static final int REQ_RESTORE_BACKUP = 4102;
    private String pendingBackupJson = null;
    private final String AUTO_BACKUP_NAME = "NosraFarm_PreRestore_Auto.json";
    private int safeTopPx = 0;
    private int safeBottomPx = 0;
    private String pendingOpenSection = null;
    private static final int REQ_NOTIFICATIONS = 4201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23,77,55));
        pendingOpenSection = getIntent() == null ? null : getIntent().getStringExtra("open_section");
        ReminderReceiver.ensureChannel(this);
        ReminderScheduler.rescheduleStored(this);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applySafeInsetsToWeb();
                openPendingSection();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                safeTopPx = bars.top;
                safeBottomPx = bars.bottom;
            } else {
                safeTopPx = insets.getSystemWindowInsetTop();
                safeBottomPx = insets.getSystemWindowInsetBottom();
            }
            applySafeInsetsToWeb();
            return insets;
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }


    private void openPendingSection() {
        if (webView == null || pendingOpenSection == null || pendingOpenSection.isEmpty()) return;
        final String sec = pendingOpenSection.replace("'", "");
        pendingOpenSection = null;
        webView.post(() -> webView.evaluateJavascript(
                "if(typeof showSec==='function'){showSec('" + sec + "')}" , null));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pendingOpenSection = intent == null ? null : intent.getStringExtra("open_section");
        openPendingSection();
    }

    private void requestNotificationPermissionNative() {
        ReminderReceiver.ensureChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        } else {
            Toast.makeText(this, "الإشعارات مفعلة", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && webView != null) {
            webView.evaluateJavascript("if(typeof renderReminderPermissionState==='function'){renderReminderPermissionState()}", null);
        }
    }

    private void applySafeInsetsToWeb() {
        if (webView == null) return;
        final int top = Math.max(0, safeTopPx);
        final int bottom = Math.max(0, safeBottomPx);
        webView.post(() -> webView.evaluateJavascript(
            "document.documentElement.style.setProperty('--system-safe-top','" + top + "px');" +
            "document.documentElement.style.setProperty('--system-safe-bottom','" + bottom + "px');",
            null));
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void captureReport(boolean share, String fileName) {
        if (captureInProgress) {
            Toast.makeText(this, "جارٍ تجهيز الصورة...", Toast.LENGTH_SHORT).show();
            return;
        }
        captureInProgress = true;
        final int oldScrollX = webView.getScrollX();
        final int oldScrollY = webView.getScrollY();
        final ViewGroup.LayoutParams currentParams = webView.getLayoutParams();
        final int oldLayoutWidth = currentParams != null ? currentParams.width : ViewGroup.LayoutParams.MATCH_PARENT;
        final int oldLayoutHeight = currentParams != null ? currentParams.height : ViewGroup.LayoutParams.MATCH_PARENT;
        final int originalWidth = webView.getWidth();
        final int originalHeight = webView.getHeight();

        webView.evaluateJavascript("window.__enterNativeCapture ? window.__enterNativeCapture() : ''", value -> {
            webView.postDelayed(() -> {
                webView.evaluateJavascript("JSON.stringify({width:window.innerWidth,height:document.documentElement.scrollHeight})", dims -> {
                    try {
                        String decoded = decodeJavascriptString(dims);
                        JSONObject o = new JSONObject(decoded == null || decoded.isEmpty() ? "{}" : decoded);
                        double cssWidth = Math.max(1.0, o.optDouble("width", 1.0));
                        double cssHeight = Math.max(1.0, o.optDouble("height", 1.0));
                        int captureWidth = Math.max(1, originalWidth);
                        int captureHeight = (int)Math.ceil(cssHeight * captureWidth / cssWidth);
                        int maxHeight = 24000;
                        if (captureHeight > maxHeight) {
                            throw new IllegalStateException("التقرير طويل جدًا للتصدير في صورة واحدة");
                        }

                        ViewGroup.LayoutParams lp = webView.getLayoutParams();
                        lp.width = captureWidth;
                        lp.height = captureHeight;
                        webView.setLayoutParams(lp);
                        int wSpec = View.MeasureSpec.makeMeasureSpec(captureWidth, View.MeasureSpec.EXACTLY);
                        int hSpec = View.MeasureSpec.makeMeasureSpec(captureHeight, View.MeasureSpec.EXACTLY);
                        webView.measure(wSpec, hSpec);
                        webView.layout(0, 0, captureWidth, captureHeight);
                        webView.scrollTo(0, 0);

                        webView.postDelayed(() -> {
                            Bitmap bitmap = null;
                            try {
                                bitmap = Bitmap.createBitmap(captureWidth, captureHeight, Bitmap.Config.ARGB_8888);
                                Canvas canvas = new Canvas(bitmap);
                                canvas.drawColor(Color.WHITE);
                                webView.draw(canvas);
                                Uri uri = writeBitmap(bitmap, fileName);
                                if (share) shareUri(uri);
                                else Toast.makeText(MainActivity.this, "تم حفظ التقرير في الصور", Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "فشل تصدير PNG: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            } finally {
                                if (bitmap != null) bitmap.recycle();
                                restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                            }
                        }, 180);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "فشل تجهيز التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                    }
                });
            }, 120);
        });
    }

    private String decodeJavascriptString(String value) throws Exception {
        if (value == null || "null".equals(value)) return "";
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return new JSONArray("[" + value + "]").getString(0);
        }
        return value;
    }

    private void restoreAfterCapture(int oldLayoutWidth, int oldLayoutHeight, int width, int height, int scrollX, int scrollY) {
        webView.evaluateJavascript("window.__exitNativeCapture && window.__exitNativeCapture()", null);
        ViewGroup.LayoutParams lp = webView.getLayoutParams();
        lp.width = oldLayoutWidth;
        lp.height = oldLayoutHeight;
        webView.setLayoutParams(lp);
        int wSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
        int hSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, height), View.MeasureSpec.EXACTLY);
        webView.measure(wSpec, hSpec);
        webView.layout(0, 0, Math.max(1, width), Math.max(1, height));
        webView.scrollTo(scrollX, scrollY);
        captureInProgress = false;
    }

    private Uri writeBitmap(Bitmap bitmap, String fileName) throws Exception {
        String safeName = (fileName == null || fileName.trim().isEmpty()) ? "NosraFarmReport.png" : fileName;
        if (!safeName.toLowerCase().endsWith(".png")) safeName += ".png";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NosraFarm");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف الصورة");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("تعذر فتح ملف الصورة");
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IllegalStateException("تعذر ضغط الصورة");
            }
            out.flush();
        }
        values.clear();
        values.put(MediaStore.Images.Media.IS_PENDING, 0);
        resolver.update(uri, values, null, null);
        return uri;
    }

    private void shareUri(Uri uri) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("image/png");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "مشاركة التقرير"));
    }


    private void startBackupExport(String json, String fileName) {
        pendingBackupJson = json;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, (fileName == null || fileName.isEmpty()) ? "NosraFarm_Backup.json" : fileName);
        startActivityForResult(intent, REQ_CREATE_BACKUP);
    }

    private void startBackupRestore(String safetyJson) {
        try {
            if (safetyJson != null && !safetyJson.isEmpty()) {
                try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), AUTO_BACKUP_NAME))) {
                    out.write(safetyJson.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء نسخة الأمان التلقائية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_RESTORE_BACKUP);
    }

    private String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private void sendBackupToWeb(String json) {
        final String quoted = JSONObject.quote(json == null ? "" : json);
        webView.evaluateJavascript("window.__restoreBackupFromAndroid && window.__restoreBackupFromAndroid(" + quoted + ")", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_CREATE_BACKUP) {
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("تعذر فتح ملف النسخة الاحتياطية");
                    out.write((pendingBackupJson == null ? "" : pendingBackupJson).getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
                pendingBackupJson = null;
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQ_RESTORE_BACKUP) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("تعذر فتح ملف النسخة الاحتياطية");
                    sendBackupToWeb(readAll(in));
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطأ في النسخ الاحتياطي: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void captureReportPng(boolean share, String fileName) {
            runOnUiThread(() -> captureReport(share, fileName));
        }

        @JavascriptInterface
        public void exportBackup(String json, String fileName) {
            runOnUiThread(() -> startBackupExport(json, fileName));
        }

        @JavascriptInterface
        public void requestRestoreBackup(String safetyJson) {
            runOnUiThread(() -> startBackupRestore(safetyJson));
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> requestNotificationPermissionNative());
        }

        @JavascriptInterface
        public boolean notificationPermissionGranted() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void syncReminders(String json) {
            runOnUiThread(() -> {
                try {
                    ReminderScheduler.syncFromJson(MainActivity.this, json);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر جدولة التنبيهات: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void restoreAutoBackup() {
            runOnUiThread(() -> {
                File f = new File(getFilesDir(), AUTO_BACKUP_NAME);
                if (!f.exists()) {
                    Toast.makeText(MainActivity.this, "لا توجد نسخة أمان تلقائية حتى الآن", Toast.LENGTH_LONG).show();
                    return;
                }
                try (InputStream in = new FileInputStream(f)) {
                    sendBackupToWeb(readAll(in));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر قراءة نسخة الأمان: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
