# Multi-Farm Season Platform Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Deliver V2 profiles, editable maps, planting age, inventory with invoice images and automatic consumption, labor cost accounting, season closing/reporting, and ZIP backup compatibility without losing existing v1 data.

**Architecture:** Bootstrap a profile layer before the existing inline app loads. Existing working localStorage keys remain the active profile workspace; switching profiles snapshots/restores those keys. New V2 modules live in `platform_v2.js`, while narrow patches adapt existing map, fertilizer/spray saves, labor table, and Android bridge.

**Tech Stack:** Android Java WebView, HTML/CSS/vanilla JS, localStorage, Android Storage Access Framework.

**Spec:** `docs/superpowers/specs/2026-10-26-multi-farm-season-platform-design.md`

## Tasks
1. Add regression tests for profile migration/switching, map schema, inventory math, season close and V2 UI hooks.
2. Add `platform_v2.js` profile bootstrap and profile manager UI; migrate v1 data into default profile and preserve active workspace.
3. Replace hard-coded A/B map rendering with profile map sectors/valves and add map editor/copy behavior.
4. Add planting-date/age dashboard metadata and explicit season close/read-only behavior.
5. Add combined fertilizer/pesticide inventory, receipts, invoice image attachment, and automatic usage rebuild from fert/spray records.
6. Add daily contractor rate storage and season labor-cost summaries.
7. Add season close report with worker-days, cost by operation, boxes/kg, inventory totals and PNG export hook.
8. Upgrade Android bridge for invoice photo gallery/camera and ZIP backup/restore; keep legacy JSON restore.
9. Bump version to 2.0.0 and run all regression checks plus ZIP integrity checks.
