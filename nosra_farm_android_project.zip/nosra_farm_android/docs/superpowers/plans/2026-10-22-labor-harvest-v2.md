# Labor & Harvest V2 Implementation Plan

**Goal:** Expand Nosra Farm with separate morning/evening/night labor workflows, PNG exports, dynamic harvest collection types, daily/monthly harvest statements, and a vehicle-loading ledger with horizontal/vertical totals.

**Architecture:** Keep the existing offline HTML/WebView/localStorage architecture. Add independent localStorage namespaces for shift labor and harvest V2, reuse existing contractors/settings/export preview, and extend the clean PNG preview modes without changing the Android capture bridge.

**Tech Stack:** HTML/CSS/JavaScript, Android WebView, localStorage, Android native PNG capture.

## Tasks
- Add separate evening/night labor UI and data keyed by date, reusing contractor/operation columns.
- Add separate PNG export for morning labor and combined evening + night security.
- Add dynamic harvest collection types with defaults Export×2, Factory×11, Trader×9; editable count/weight/factor; add/edit/archive types.
- Add daily harvest statement and month aggregate matrix with per-type and grand totals.
- Add independent vehicle-loading page with vehicles as columns, contractors as rows, per-vehicle totals, per-contractor totals, and grand total.
- Add clean PNG exports for daily harvest, monthly harvest, and vehicle loading.
- Preserve existing records/settings and responsive S24 Ultra layout.
- Verify JS syntax and static requirements before packaging the project ZIP.
