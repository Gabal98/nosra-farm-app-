# Fertilizer Reminders Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add reliable local fertilizer reminder notifications with one-time, daily, weekly, and monthly recurrence.

**Architecture:** Store reminder UI data in LocalStorage and mirror enabled schedules to Android SharedPreferences. AlarmManager fires a BroadcastReceiver which posts a notification and reschedules repeating reminders; boot receiver rebuilds alarms.

**Tech Stack:** Android Java 17, WebView JavaScript/HTML, AlarmManager, NotificationManager, SharedPreferences.

**Spec:** `docs/superpowers/specs/2026-10-25-fertilizer-reminders-design.md`

## Global Constraints
- Keep package `com.nosrafarm.app` and fixed signing key.
- Preserve all existing LocalStorage data and Backup/Restore behavior.
- No internet dependency for reminders.
- Monthly recurrence clamps invalid day-of-month to month end.

## Review Focus
- Android 13+ permission denied must not crash.
- One-time past reminders must not schedule.
- Monthly reminders on days 29-31 must still fire in shorter months.
- Disabled/deleted reminders must cancel prior PendingIntents.
- Boot/app update must restore enabled reminders.

### Task 1: Recurrence calculation
**Files:** Create `ReminderTime.java`; create `tests/ReminderTimeTest.java`.
- [ ] Write failing tests for once/daily/weekly/monthly and month-end clamp.
- [ ] Implement next trigger calculation.
- [ ] Run pure Java tests.

### Task 2: Native scheduling and notifications
**Files:** Create `ReminderScheduler.java`, `ReminderReceiver.java`, `BootReceiver.java`; modify Manifest and MainActivity.
- [ ] Add notification permission/channel and runtime permission request.
- [ ] Add JS bridge methods to sync/cancel reminders.
- [ ] Persist schedule JSON in SharedPreferences and schedule/cancel alarms.
- [ ] Add receivers and reschedule on boot/package replace.

### Task 3: Reminder UI and sync
**Files:** Modify `assets/index.html`; create `tests/regression_reminders.js`.
- [ ] Add nav/section, form, list, edit/delete/enable controls.
- [ ] Populate fertilizer program and valves from existing app data.
- [ ] Sync reminders to Android after save/delete/toggle/load/restore.
- [ ] Verify UI source and existing Backup/Restore remain present.

### Task 4: Version and verification
**Files:** Modify `app/build.gradle.kts`.
- [ ] Bump versionCode/versionName.
- [ ] Run JS syntax/regression tests and pure Java recurrence tests.
- [ ] Validate ZIP structure and manifest permissions/receivers.
