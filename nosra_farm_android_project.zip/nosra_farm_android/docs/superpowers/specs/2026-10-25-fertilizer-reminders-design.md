# Fertilizer Reminders Design

Goal: add local Android notifications for fertilizer injections without changing existing farm data or requiring internet.

The app gets a new "التنبيهات" section. Each reminder stores a title, fertilizer program, date, time, recurrence (`once`, `daily`, `weekly`, `monthly`), optional sector/valves, notes, and enabled state. Reminder records remain in LocalStorage for UI/backup compatibility and are mirrored to Android SharedPreferences for scheduling while the app is closed.

Android requests `POST_NOTIFICATIONS` on Android 13+. AlarmManager schedules the next one-shot occurrence; repeating reminders are rescheduled by the receiver after firing. Monthly reminders use the selected day-of-month and clamp to the last valid day when a month is shorter. On boot/app update, enabled reminders are rescheduled from SharedPreferences. No exact-alarm special permission is required; reminders use `setAndAllowWhileIdle`.

Notifications open Nosra Farm and navigate to the reminders section. Existing Backup/Restore automatically includes reminder LocalStorage; after restore/reload the web UI re-syncs schedules to Android.
