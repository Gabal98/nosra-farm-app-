# Nosra Farm V2 — Multi-farm / Multi-crop / Season Profiles

## Intent
Turn the existing strawberry-season app into a reusable farm platform. The user creates a profile for one farm + one crop + one season. Each profile keeps its own map, crop records, fertilizer/pesticide inventory, planting dates, labor, harvest, reports, reminders and attachments. Old seasons remain available permanently.

## Core behavior
- A profile is `farm + crop + season`; multiple profiles may exist at once, even for the same farm.
- One valve belongs to one crop inside a profile. Profiles never share mutable season data.
- A new profile can copy the previous profile map or start with a fresh editable map.
- Ending a season is explicit. The user chooses the final date. Closed profiles are read-only and remain reportable.
- Existing v1.x local data migrates into a default profile instead of being deleted.

## Map
Editable sectors and valves: sector code/name, valve name, area, order. Each profile stores an independent snapshot. A copied map is duplicated, never linked to the old season.

## Planting age
Each profile stores planting date. The dashboard displays plant age in days and updates from the current date.

## Inventory
One combined fertilizer/pesticide inventory per profile. Product definition: product name, unit size/weight, unit (`kg`, `g`, `L`, `ml`). Receipts store date, number of units, optional invoice number/note, and optional photographed invoice. Fertilizer and spray records generate usage from their saved program snapshots, so edits/deletes can rebuild usage and current balance.

## Labor costs
Daily labor keeps contractor x operation counts and adds an editable cost per worker for that date/contractor. Season reports calculate worker-days and labor cost by operation and contractor.

## Season close report
Show start/end/duration, total worker-days, labor cost by operation, total harvest boxes and kg, harvest-day count, inventory receipts/usage/balance by product. Export remains PNG using the existing reporting flow.

## Backup
Backup contains all localStorage including profiles and invoice images. Android export uses a ZIP container with backup.json; restore accepts the new ZIP and legacy JSON. Android document picker allows Google Drive as a destination/source.

## Compatibility
Keep package `com.nosrafarm.app`, fixed signing key, current strawberry workflows, PNG exports, reminders, dark theme, backup/restore. Version becomes 2.0.0 with a higher versionCode.
