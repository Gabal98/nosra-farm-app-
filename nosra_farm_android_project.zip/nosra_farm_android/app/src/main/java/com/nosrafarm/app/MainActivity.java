package com.nosrafarm.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean captureInProgress = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23,77,55));

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void captureReport(boolean share, String fileName) {
        if (captureInProgress) {
            Toast.makeText(this, "جارٍ تجهيز الصورة...", Toast.LENGTH_SHORT).show();
            return;
        }
        captureInProgress = true;
        final int oldScrollX = webView.getScrollX();
        final int oldScrollY = webView.getScrollY();
        final ViewGroup.LayoutParams currentParams = webView.getLayoutParams();
        final int oldLayoutWidth = currentParams != null ? currentParams.width : ViewGroup.LayoutParams.MATCH_PARENT;
        final int oldLayoutHeight = currentParams != null ? currentParams.height : ViewGroup.LayoutParams.MATCH_PARENT;
        final int originalWidth = webView.getWidth();
        final int originalHeight = webView.getHeight();

        webView.evaluateJavascript("window.__enterNativeCapture ? window.__enterNativeCapture() : ''", value -> {
            webView.postDelayed(() -> {
                webView.evaluateJavascript("JSON.stringify({width:window.innerWidth,height:document.documentElement.scrollHeight})", dims -> {
                    try {
                        String decoded = decodeJavascriptString(dims);
                        JSONObject o = new JSONObject(decoded == null || decoded.isEmpty() ? "{}" : decoded);
                        double cssWidth = Math.max(1.0, o.optDouble("width", 1.0));
                        double cssHeight = Math.max(1.0, o.optDouble("height", 1.0));
                        int captureWidth = Math.max(1, originalWidth);
                        int captureHeight = (int)Math.ceil(cssHeight * captureWidth / cssWidth);
                        int maxHeight = 24000;
                        if (captureHeight > maxHeight) {
                            throw new IllegalStateException("التقرير طويل جدًا للتصدير في صورة واحدة");
                        }

                        ViewGroup.LayoutParams lp = webView.getLayoutParams();
                        lp.width = captureWidth;
                        lp.height = captureHeight;
                        webView.setLayoutParams(lp);
                        int wSpec = View.MeasureSpec.makeMeasureSpec(captureWidth, View.MeasureSpec.EXACTLY);
                        int hSpec = View.MeasureSpec.makeMeasureSpec(captureHeight, View.MeasureSpec.EXACTLY);
                        webView.measure(wSpec, hSpec);
                        webView.layout(0, 0, captureWidth, captureHeight);
                        webView.scrollTo(0, 0);

                        webView.postDelayed(() -> {
                            Bitmap bitmap = null;
                            try {
                                bitmap = Bitmap.createBitmap(captureWidth, captureHeight, Bitmap.Config.ARGB_8888);
                                Canvas canvas = new Canvas(bitmap);
                                canvas.drawColor(Color.WHITE);
                                webView.draw(canvas);
                                Uri uri = writeBitmap(bitmap, fileName);
                                if (share) shareUri(uri);
                                else Toast.makeText(MainActivity.this, "تم حفظ التقرير في الصور", Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "فشل تصدير PNG: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            } finally {
                                if (bitmap != null) bitmap.recycle();
                                restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                            }
                        }, 180);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "فشل تجهيز التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                    }
                });
            }, 120);
        });
    }

    private String decodeJavascriptString(String value) throws Exception {
        if (value == null || "null".equals(value)) return "";
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return new JSONArray("[" + value + "]").getString(0);
        }
        return value;
    }

    private void restoreAfterCapture(int oldLayoutWidth, int oldLayoutHeight, int width, int height, int scrollX, int scrollY) {
        webView.evaluateJavascript("window.__exitNativeCapture && window.__exitNativeCapture()", null);
        ViewGroup.LayoutParams lp = webView.getLayoutParams();
        lp.width = oldLayoutWidth;
        lp.height = oldLayoutHeight;
        webView.setLayoutParams(lp);
        int wSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
        int hSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, height), View.MeasureSpec.EXACTLY);
        webView.measure(wSpec, hSpec);
        webView.layout(0, 0, Math.max(1, width), Math.max(1, height));
        webView.scrollTo(scrollX, scrollY);
        captureInProgress = false;
    }

    private Uri writeBitmap(Bitmap bitmap, String fileName) throws Exception {
        String safeName = (fileName == null || fileName.trim().isEmpty()) ? "NosraFarmReport.png" : fileName;
        if (!safeName.toLowerCase().endsWith(".png")) safeName += ".png";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NosraFarm");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف الصورة");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("تعذر فتح ملف الصورة");
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IllegalStateException("تعذر ضغط الصورة");
            }
            out.flush();
        }
        values.clear();
        values.put(MediaStore.Images.Media.IS_PENDING, 0);
        resolver.update(uri, values, null, null);
        return uri;
    }

    private void shareUri(Uri uri) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("image/png");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "مشاركة التقرير"));
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void captureReportPng(boolean share, String fileName) {
            runOnUiThread(() -> captureReport(share, fileName));
        }
    }
}
