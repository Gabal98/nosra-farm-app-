package com.nosrafarm.app;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.graphics.Canvas;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.os.Build;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean captureInProgress = false;
    private static final int REQ_CREATE_BACKUP = 4101;
    private static final int REQ_RESTORE_BACKUP = 4102;
    private static final int REQ_INVOICE_GALLERY = 4301;
    private static final int REQ_INVOICE_CAMERA = 4302;
    private String pendingBackupJson = null;
    private final String AUTO_BACKUP_NAME = "NosraFarm_PreRestore_Auto.zip";
    private Uri pendingInvoiceCameraUri = null;
    private int safeTopPx = 0;
    private int safeBottomPx = 0;
    private String pendingOpenSection = null;
    private static final int REQ_NOTIFICATIONS = 4201;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23,77,55));
        pendingOpenSection = getIntent() == null ? null : getIntent().getStringExtra("open_section");
        ReminderReceiver.ensureChannel(this);
        ReminderScheduler.rescheduleStored(this);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applySafeInsetsToWeb();
                openPendingSection();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                safeTopPx = bars.top;
                safeBottomPx = bars.bottom;
            } else {
                safeTopPx = insets.getSystemWindowInsetTop();
                safeBottomPx = insets.getSystemWindowInsetBottom();
            }
            applySafeInsetsToWeb();
            return insets;
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }


    private void openPendingSection() {
        if (webView == null || pendingOpenSection == null || pendingOpenSection.isEmpty()) return;
        final String sec = pendingOpenSection.replace("'", "");
        pendingOpenSection = null;
        webView.post(() -> webView.evaluateJavascript(
                "if(typeof showSec==='function'){showSec('" + sec + "')}" , null));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pendingOpenSection = intent == null ? null : intent.getStringExtra("open_section");
        openPendingSection();
    }

    private void requestNotificationPermissionNative() {
        ReminderReceiver.ensureChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        } else {
            Toast.makeText(this, "الإشعارات مفعلة", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && webView != null) {
            webView.evaluateJavascript("if(typeof renderReminderPermissionState==='function'){renderReminderPermissionState()}", null);
        }
    }

    private void applySafeInsetsToWeb() {
        if (webView == null) return;
        final int top = Math.max(0, safeTopPx);
        final int bottom = Math.max(0, safeBottomPx);
        webView.post(() -> webView.evaluateJavascript(
            "document.documentElement.style.setProperty('--system-safe-top','" + top + "px');" +
            "document.documentElement.style.setProperty('--system-safe-bottom','" + bottom + "px');",
            null));
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private void captureReport(boolean share, String fileName) {
        if (captureInProgress) {
            Toast.makeText(this, "جارٍ تجهيز الصورة...", Toast.LENGTH_SHORT).show();
            return;
        }
        captureInProgress = true;
        final int oldScrollX = webView.getScrollX();
        final int oldScrollY = webView.getScrollY();
        final ViewGroup.LayoutParams currentParams = webView.getLayoutParams();
        final int oldLayoutWidth = currentParams != null ? currentParams.width : ViewGroup.LayoutParams.MATCH_PARENT;
        final int oldLayoutHeight = currentParams != null ? currentParams.height : ViewGroup.LayoutParams.MATCH_PARENT;
        final int originalWidth = webView.getWidth();
        final int originalHeight = webView.getHeight();

        webView.evaluateJavascript("window.__enterNativeCapture ? window.__enterNativeCapture() : ''", value -> {
            webView.postDelayed(() -> {
                webView.evaluateJavascript("JSON.stringify({width:window.innerWidth,height:document.documentElement.scrollHeight})", dims -> {
                    try {
                        String decoded = decodeJavascriptString(dims);
                        JSONObject o = new JSONObject(decoded == null || decoded.isEmpty() ? "{}" : decoded);
                        double cssWidth = Math.max(1.0, o.optDouble("width", 1.0));
                        double cssHeight = Math.max(1.0, o.optDouble("height", 1.0));
                        int captureWidth = Math.max(1, originalWidth);
                        int captureHeight = (int)Math.ceil(cssHeight * captureWidth / cssWidth);
                        int maxHeight = 24000;
                        if (captureHeight > maxHeight) {
                            throw new IllegalStateException("التقرير طويل جدًا للتصدير في صورة واحدة");
                        }

                        ViewGroup.LayoutParams lp = webView.getLayoutParams();
                        lp.width = captureWidth;
                        lp.height = captureHeight;
                        webView.setLayoutParams(lp);
                        int wSpec = View.MeasureSpec.makeMeasureSpec(captureWidth, View.MeasureSpec.EXACTLY);
                        int hSpec = View.MeasureSpec.makeMeasureSpec(captureHeight, View.MeasureSpec.EXACTLY);
                        webView.measure(wSpec, hSpec);
                        webView.layout(0, 0, captureWidth, captureHeight);
                        webView.scrollTo(0, 0);

                        webView.postDelayed(() -> {
                            Bitmap bitmap = null;
                            try {
                                bitmap = Bitmap.createBitmap(captureWidth, captureHeight, Bitmap.Config.ARGB_8888);
                                Canvas canvas = new Canvas(bitmap);
                                canvas.drawColor(Color.WHITE);
                                webView.draw(canvas);
                                Uri uri = writeBitmap(bitmap, fileName);
                                if (share) shareUri(uri);
                                else Toast.makeText(MainActivity.this, "تم حفظ التقرير في الصور", Toast.LENGTH_LONG).show();
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "فشل تصدير PNG: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            } finally {
                                if (bitmap != null) bitmap.recycle();
                                restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                            }
                        }, 180);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "فشل تجهيز التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        restoreAfterCapture(oldLayoutWidth, oldLayoutHeight, originalWidth, originalHeight, oldScrollX, oldScrollY);
                    }
                });
            }, 120);
        });
    }

    private String decodeJavascriptString(String value) throws Exception {
        if (value == null || "null".equals(value)) return "";
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return new JSONArray("[" + value + "]").getString(0);
        }
        return value;
    }

    private void restoreAfterCapture(int oldLayoutWidth, int oldLayoutHeight, int width, int height, int scrollX, int scrollY) {
        webView.evaluateJavascript("window.__exitNativeCapture && window.__exitNativeCapture()", null);
        ViewGroup.LayoutParams lp = webView.getLayoutParams();
        lp.width = oldLayoutWidth;
        lp.height = oldLayoutHeight;
        webView.setLayoutParams(lp);
        int wSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
        int hSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, height), View.MeasureSpec.EXACTLY);
        webView.measure(wSpec, hSpec);
        webView.layout(0, 0, Math.max(1, width), Math.max(1, height));
        webView.scrollTo(scrollX, scrollY);
        captureInProgress = false;
    }

    private Uri writeBitmap(Bitmap bitmap, String fileName) throws Exception {
        String safeName = (fileName == null || fileName.trim().isEmpty()) ? "NosraFarmReport.png" : fileName;
        if (!safeName.toLowerCase().endsWith(".png")) safeName += ".png";

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NosraFarm");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف الصورة");
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("تعذر فتح ملف الصورة");
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                throw new IllegalStateException("تعذر ضغط الصورة");
            }
            out.flush();
        }
        values.clear();
        values.put(MediaStore.Images.Media.IS_PENDING, 0);
        resolver.update(uri, values, null, null);
        return uri;
    }

    private void shareUri(Uri uri) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("image/png");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "مشاركة التقرير"));
    }


    private void startBackupExport(String json, String fileName) {
        pendingBackupJson = json;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE, (fileName == null || fileName.isEmpty()) ? "NosraFarm_Backup.zip" : fileName);
        startActivityForResult(intent, REQ_CREATE_BACKUP);
    }

    private void startBackupRestore(String safetyJson) {
        try {
            if (safetyJson != null && !safetyJson.isEmpty()) {
                try (FileOutputStream fos = new FileOutputStream(new File(getFilesDir(), AUTO_BACKUP_NAME))) {
                    writeBackupZip(fos, safetyJson);
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر إنشاء نسخة الأمان التلقائية: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip","application/json","application/octet-stream"});
        startActivityForResult(intent, REQ_RESTORE_BACKUP);
    }

    private String readAll(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    private File invoiceDir() {
        File dir = new File(getFilesDir(), "invoices");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private void writeBackupZip(OutputStream rawOut, String json) throws Exception {
        try (ZipOutputStream zos = new ZipOutputStream(rawOut)) {
            zos.putNextEntry(new ZipEntry("backup.json"));
            zos.write((json == null ? "" : json).getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            File[] files = invoiceDir().listFiles();
            if (files != null) {
                byte[] buf = new byte[8192];
                for (File f : files) {
                    if (!f.isFile()) continue;
                    zos.putNextEntry(new ZipEntry("invoices/" + f.getName()));
                    try (InputStream in = new FileInputStream(f)) {
                        int n;
                        while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                    }
                    zos.closeEntry();
                }
            }
        }
    }

    private String readBackupPayload(InputStream raw) throws Exception {
        BufferedInputStream in = new BufferedInputStream(raw);
        in.mark(4);
        int a = in.read();
        int b = in.read();
        in.reset();
        if (a == 'P' && b == 'K') {
            String json = null;
            try (ZipInputStream zis = new ZipInputStream(in)) {
                ZipEntry entry;
                byte[] buf = new byte[8192];
                while ((entry = zis.getNextEntry()) != null) {
                    if (entry.isDirectory()) continue;
                    if ("backup.json".equals(entry.getName())) {
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        int n;
                        while ((n = zis.read(buf)) > 0) bos.write(buf, 0, n);
                        json = bos.toString(StandardCharsets.UTF_8.name());
                    } else if (entry.getName().startsWith("invoices/")) {
                        String name = new File(entry.getName()).getName();
                        if (name.isEmpty()) continue;
                        try (FileOutputStream out = new FileOutputStream(new File(invoiceDir(), name))) {
                            int n;
                            while ((n = zis.read(buf)) > 0) out.write(buf, 0, n);
                        }
                    }
                }
            }
            if (json == null) throw new IllegalStateException("ملف النسخة لا يحتوي backup.json");
            return json;
        }
        return readAll(in);
    }

    private Bitmap decodeInvoiceBitmap(Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("تعذر فتح الصورة");
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 2200) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        Bitmap bitmap;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("تعذر فتح الصورة");
            bitmap = BitmapFactory.decodeStream(in, null, opts);
        }
        if (bitmap == null) throw new IllegalStateException("تعذر قراءة الصورة");
        int w = bitmap.getWidth(), h = bitmap.getHeight(), max = 1600;
        if (Math.max(w, h) > max) {
            float scale = max / (float)Math.max(w, h);
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), true);
            if (scaled != bitmap) bitmap.recycle();
            bitmap = scaled;
        }
        return bitmap;
    }

    private String bitmapDataUrl(Bitmap bitmap) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 76, bos);
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    private String storeInvoiceBitmap(Bitmap bitmap) throws Exception {
        String token = "invoice_" + System.currentTimeMillis() + "_" + Math.abs((int)(Math.random() * 100000)) + ".jpg";
        try (FileOutputStream out = new FileOutputStream(new File(invoiceDir(), token))) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)) throw new IllegalStateException("تعذر حفظ صورة الفاتورة");
        }
        return token;
    }

    private String invoiceDataUrl(String token) throws Exception {
        if (token == null || token.contains("/") || token.contains("\\")) return "";
        File f = new File(invoiceDir(), token);
        if (!f.exists()) return "";
        byte[] bytes;
        try (InputStream in = new FileInputStream(f); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            bytes = bos.toByteArray();
        }
        return "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    private void sendInvoicePhotoToWeb(Uri uri) {
        if (uri == null) return;
        Bitmap bitmap = null;
        try {
            bitmap = decodeInvoiceBitmap(uri);
            String token = storeInvoiceBitmap(bitmap);
            String preview = bitmapDataUrl(bitmap);
            webView.evaluateJavascript("window.__invoicePhotoFromAndroid && window.__invoicePhotoFromAndroid(" + JSONObject.quote(token) + "," + JSONObject.quote(preview) + ")", null);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تجهيز صورة الفاتورة: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private void pickInvoiceImageNative(String mode) {
        if ("camera".equals(mode)) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "NosraFarm_Invoice_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NosraFarm/Invoices");
            pendingInvoiceCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingInvoiceCameraUri == null) {
                Toast.makeText(this, "تعذر إنشاء ملف للصورة", Toast.LENGTH_LONG).show();
                return;
            }
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingInvoiceCameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(camera, REQ_INVOICE_CAMERA);
        } else {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("image/*");
            startActivityForResult(pick, REQ_INVOICE_GALLERY);
        }
    }

    private void sendBackupToWeb(String json) {
        final String quoted = JSONObject.quote(json == null ? "" : json);
        webView.evaluateJavascript("window.__restoreBackupFromAndroid && window.__restoreBackupFromAndroid(" + quoted + ")", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) return;
        if (requestCode == REQ_INVOICE_CAMERA) {
            sendInvoicePhotoToWeb(pendingInvoiceCameraUri);
            pendingInvoiceCameraUri = null;
            return;
        }
        if (data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_CREATE_BACKUP) {
                try (OutputStream rawOut = getContentResolver().openOutputStream(uri)) {
                    if (rawOut == null) throw new IllegalStateException("تعذر فتح ملف النسخة الاحتياطية");
                    writeBackupZip(rawOut, pendingBackupJson == null ? "" : pendingBackupJson);
                }
                pendingBackupJson = null;
                Toast.makeText(this, "تم حفظ النسخة الاحتياطية ZIP", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQ_RESTORE_BACKUP) {
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    if (in == null) throw new IllegalStateException("تعذر فتح ملف النسخة الاحتياطية");
                    sendBackupToWeb(readBackupPayload(in));
                }
            } else if (requestCode == REQ_INVOICE_GALLERY) {
                sendInvoicePhotoToWeb(uri);
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void captureReportPng(boolean share, String fileName) {
            runOnUiThread(() -> captureReport(share, fileName));
        }

        @JavascriptInterface
        public void pickInvoiceImage(String mode) {
            runOnUiThread(() -> pickInvoiceImageNative(mode));
        }

        @JavascriptInterface
        public String getInvoiceImageData(String token) {
            try { return invoiceDataUrl(token); }
            catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public void deleteInvoiceImage(String token) {
            runOnUiThread(() -> {
                try {
                    if (token == null || token.contains("/") || token.contains("\\")) return;
                    File f = new File(invoiceDir(), token);
                    if (f.exists()) f.delete();
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void exportBackup(String json, String fileName) {
            runOnUiThread(() -> startBackupExport(json, fileName));
        }

        @JavascriptInterface
        public void requestRestoreBackup(String safetyJson) {
            runOnUiThread(() -> startBackupRestore(safetyJson));
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> requestNotificationPermissionNative());
        }

        @JavascriptInterface
        public boolean notificationPermissionGranted() {
            return Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void syncReminders(String json) {
            runOnUiThread(() -> {
                try {
                    ReminderScheduler.syncFromJson(MainActivity.this, json);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر جدولة التنبيهات: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void restoreAutoBackup() {
            runOnUiThread(() -> {
                File f = new File(getFilesDir(), AUTO_BACKUP_NAME);
                if (!f.exists()) {
                    Toast.makeText(MainActivity.this, "لا توجد نسخة أمان تلقائية حتى الآن", Toast.LENGTH_LONG).show();
                    return;
                }
                try (InputStream in = new FileInputStream(f)) {
                    sendBackupToWeb(readBackupPayload(in));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر قراءة نسخة الأمان: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
