package com.nosrafarm.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "fertilizer_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent == null ? "" : intent.getStringExtra("reminder_id");
        if (id == null || id.isEmpty()) return;
        JSONObject item = ReminderScheduler.findById(context, id);
        if (item == null || !item.optBoolean("enabled", true)) return;

        ensureChannel(context);
        String title = item.optString("title", "تذكير تسميد");
        if (title.trim().isEmpty()) title = "تذكير تسميد";
        String program = item.optString("programName", "");
        String valves = item.optString("valvesText", "");
        String notes = item.optString("notes", "");
        StringBuilder body = new StringBuilder();
        if (!program.isEmpty()) body.append(program);
        if (!valves.isEmpty()) { if (body.length() > 0) body.append(" — "); body.append(valves); }
        if (!notes.isEmpty()) { if (body.length() > 0) body.append("\n"); body.append(notes); }
        if (body.length() == 0) body.append("موعد حقنة التسميد المسجلة");

        Intent open = new Intent(context, MainActivity.class);
        open.putExtra("open_section", "reminders");
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(context, id.hashCode() & 0x7fffffff, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(body.toString().replace('\n', ' '))
                .setStyle(new Notification.BigTextStyle().bigText(body.toString()))
                .setAutoCancel(true)
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setPriority(Notification.PRIORITY_HIGH);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
            nm.notify(id.hashCode() & 0x7fffffff, b.build());
        }

        String repeat = item.optString("repeat", "once");
        if (!"once".equals(repeat)) ReminderScheduler.scheduleOne(context, item, System.currentTimeMillis() + 1000L);
    }

    public static void ensureChannel(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "تنبيهات التسميد", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("تذكيرات برامج وحقن التسميد في مزرعة نصرة");
        nm.createNotificationChannel(ch);
    }
}
