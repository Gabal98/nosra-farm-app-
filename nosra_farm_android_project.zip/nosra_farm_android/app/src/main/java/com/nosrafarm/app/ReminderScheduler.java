package com.nosrafarm.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public final class ReminderScheduler {
    public static final String PREFS = "nosra_reminders_native";
    public static final String KEY_JSON = "reminders_json";

    private ReminderScheduler() {}

    public static void syncFromJson(Context context, String json) throws Exception {
        JSONArray oldItems = load(context);
        cancelArray(context, oldItems);
        JSONArray newItems = new JSONArray(json == null || json.trim().isEmpty() ? "[]" : json);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_JSON, newItems.toString()).apply();
        scheduleArray(context, newItems);
    }

    public static JSONArray load(Context context) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return new JSONArray(p.getString(KEY_JSON, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void rescheduleStored(Context context) {
        JSONArray items = load(context);
        cancelArray(context, items);
        scheduleArray(context, items);
    }

    public static void scheduleOne(Context context, JSONObject item, long nowMillis) {
        try {
            if (!item.optBoolean("enabled", true)) return;
            String id = item.optString("id", "");
            if (id.isEmpty()) return;
            long trigger = ReminderTime.nextTrigger(nowMillis,
                    item.optString("date", ""), item.optString("time", ""), item.optString("repeat", "once"));
            if (trigger <= 0) return;

            Intent i = new Intent(context, ReminderReceiver.class);
            i.putExtra("reminder_id", id);
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(id), i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        } catch (Exception ignored) {}
    }

    public static JSONObject findById(Context context, String id) {
        JSONArray a = load(context);
        for (int x = 0; x < a.length(); x++) {
            JSONObject o = a.optJSONObject(x);
            if (o != null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    private static void scheduleArray(Context context, JSONArray a) {
        long now = System.currentTimeMillis();
        for (int x = 0; x < a.length(); x++) {
            JSONObject o = a.optJSONObject(x);
            if (o != null) scheduleOne(context, o, now);
        }
    }

    private static void cancelArray(Context context, JSONArray a) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int x = 0; x < a.length(); x++) {
            JSONObject o = a.optJSONObject(x);
            if (o == null) continue;
            String id = o.optString("id", "");
            if (id.isEmpty()) continue;
            Intent i = new Intent(context, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode(id), i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }
    }

    private static int requestCode(String id) {
        return id.hashCode() & 0x7fffffff;
    }
}
