package com.nosrafarm.app;

import java.util.Calendar;

public final class ReminderTime {
    private ReminderTime() {}

    public static long nextTrigger(long nowMillis, String date, String time, String repeat) {
        try {
            int[] d = parseDate(date);
            int[] t = parseTime(time);
            Calendar base = calendar(d[0], d[1], d[2], t[0], t[1]);
            long baseMillis = base.getTimeInMillis();
            if ("once".equals(repeat)) return baseMillis > nowMillis ? baseMillis : -1L;

            if ("daily".equals(repeat)) {
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(Math.max(nowMillis, baseMillis));
                Calendar candidate = calendar(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1,
                        c.get(Calendar.DAY_OF_MONTH), t[0], t[1]);
                if (candidate.getTimeInMillis() < baseMillis) candidate = (Calendar) base.clone();
                while (candidate.getTimeInMillis() <= nowMillis) candidate.add(Calendar.DAY_OF_MONTH, 1);
                return candidate.getTimeInMillis();
            }

            if ("weekly".equals(repeat)) {
                Calendar candidate = (Calendar) base.clone();
                while (candidate.getTimeInMillis() <= nowMillis) candidate.add(Calendar.DAY_OF_MONTH, 7);
                return candidate.getTimeInMillis();
            }

            if ("monthly".equals(repeat)) {
                if (baseMillis > nowMillis) return baseMillis;
                int desiredDay = d[2];
                Calendar now = Calendar.getInstance();
                now.setTimeInMillis(nowMillis);
                Calendar candidate = monthlyCandidate(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1,
                        desiredDay, t[0], t[1]);
                if (candidate.getTimeInMillis() <= nowMillis) {
                    candidate.add(Calendar.MONTH, 1);
                    int y = candidate.get(Calendar.YEAR);
                    int m = candidate.get(Calendar.MONTH) + 1;
                    candidate = monthlyCandidate(y, m, desiredDay, t[0], t[1]);
                }
                return candidate.getTimeInMillis();
            }
            return -1L;
        } catch (Exception ignored) {
            return -1L;
        }
    }

    private static Calendar monthlyCandidate(int year, int month, int desiredDay, int hour, int minute) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month - 1, 1, hour, minute, 0);
        int last = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        c.set(Calendar.DAY_OF_MONTH, Math.min(desiredDay, last));
        return c;
    }

    private static Calendar calendar(int year, int month, int day, int hour, int minute) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.setLenient(false);
        c.set(year, month - 1, day, hour, minute, 0);
        c.getTimeInMillis();
        return c;
    }

    private static int[] parseDate(String value) {
        String[] p = value == null ? new String[0] : value.split("-");
        if (p.length != 3) throw new IllegalArgumentException("date");
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1]), Integer.parseInt(p[2])};
    }

    private static int[] parseTime(String value) {
        String[] p = value == null ? new String[0] : value.split(":");
        if (p.length < 2) throw new IllegalArgumentException("time");
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
    }
}
