# مزرعة نصرة Android

تطبيق Android مستقل يعمل Offline ويعرض نظام إدارة القطاع الزراعي من الأصول المحلية داخل WebView.

- اسم التطبيق: مزرعة نصرة
- Package: com.nosrafarm.app
- Minimum Android: 8.0 (API 26)
- حفظ PNG: مجلد Pictures/NosraFarm عبر MediaStore
- مشاركة PNG: Android Share Sheet
- PDF/طباعة: Android PrintManager

## بناء APK
يتضمن المشروع GitHub Actions workflow يبني APK Debug تلقائيًا.
