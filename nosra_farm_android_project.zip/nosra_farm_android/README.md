# مزرعة نصرة Android

تطبيق Android مستقل يعمل Offline ويعرض نظام إدارة القطاع الزراعي من الأصول المحلية داخل WebView.

- اسم التطبيق: مزرعة نصرة
- Package: com.nosrafarm.app
- Minimum Android: 8.0 (API 26)
- حفظ PNG: مجلد Pictures/NosraFarm عبر MediaStore
- مشاركة PNG: Android Share Sheet
- PDF/طباعة: Android PrintManager

## بناء APK
يتضمن المشروع GitHub Actions workflow يبني APK Debug تلقائيًا.

## V2.0.0 platform update
- Farm + crop + season profiles with isolated local data and archival season closing.
- Editable per-profile map (sectors, valves, areas) with optional map copying for new seasons.
- Planting date and live plant-age calculation.
- Combined fertilizer/pesticide inventory with receipts, automatic fert/spray usage, and invoice photos.
- Daily contractor cost-per-worker and season labor cost summaries.
- Season-close report for worker-days, operation costs, harvest boxes/kg, and inventory totals.
- ZIP backup/restore compatible with Android document providers such as Google Drive; legacy JSON restore remains supported.
