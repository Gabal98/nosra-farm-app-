const assert=require('assert');
class LS{constructor(seed={}){this.m=new Map(Object.entries(seed))}get length(){return this.m.size}key(i){return [...this.m.keys()][i]??null}getItem(k){return this.m.has(k)?this.m.get(k):null}setItem(k,v){this.m.set(k,String(v))}removeItem(k){this.m.delete(k)}clear(){this.m.clear()}}
global.localStorage=new LS({farmDemoRecords:JSON.stringify([{date:'2026-01-01',type:'جمع'}]),farmFertProgramsV6:'[{"id":1}]'});
global.location={reload(){global.__reloaded=true}};
require('../app/src/main/assets/platform_v2.js');
assert(global.V2,'V2 global exists');
assert.equal(global.V2.getProfiles().length,1,'migrates current app into one profile');
const first=global.V2.activeProfile();
const snap=JSON.parse(localStorage.getItem('farmProfileDataV2::'+first.id));
assert(snap.farmDemoRecords.includes('2026-01-01'),'existing records snapshotted into default profile');
const p2=global.V2.createProfile({farmName:'مزرعة 2',cropName:'فلفل',seasonName:'موسم 2027',copyMap:true,startDate:'2027-01-01'});
const seed=JSON.parse(localStorage.getItem('farmProfileDataV2::'+p2.id));
assert.equal(seed.farmDemoRecords,'[]','new profile starts with empty records');
global.V2.switchProfile(p2.id);
assert.equal(localStorage.getItem('farmDemoRecords'),'[]','switch restores target profile workspace');
assert.equal(global.__reloaded,true,'switch requests reload');
console.log('platform_v2_profiles: PASS');
