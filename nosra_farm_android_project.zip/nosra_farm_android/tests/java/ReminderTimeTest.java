import com.nosrafarm.app.ReminderTime;
import java.util.*;

public class ReminderTimeTest {
  static long ts(int y,int m,int d,int h,int min){Calendar c=Calendar.getInstance();c.clear();c.set(y,m-1,d,h,min,0);return c.getTimeInMillis();}
  static void eq(long a,long b,String name){if(a!=b)throw new AssertionError(name+" expected "+b+" got "+a);}
  static void isTrue(boolean v,String name){if(!v)throw new AssertionError(name);}
  public static void main(String[] args){
    eq(ReminderTime.nextTrigger(ts(2026,10,25,7,0), "2026-10-25", "08:30", "once"), ts(2026,10,25,8,30), "once future");
    eq(ReminderTime.nextTrigger(ts(2026,10,25,9,0), "2026-10-25", "08:30", "once"), -1L, "once past");
    eq(ReminderTime.nextTrigger(ts(2026,10,25,9,0), "2026-10-25", "08:30", "daily"), ts(2026,10,26,8,30), "daily next");
    eq(ReminderTime.nextTrigger(ts(2026,10,26,9,0), "2026-10-25", "08:30", "weekly"), ts(2026,11,1,8,30), "weekly next");
    eq(ReminderTime.nextTrigger(ts(2026,2,20,9,0), "2026-01-31", "08:30", "monthly"), ts(2026,2,28,8,30), "monthly clamp");
    eq(ReminderTime.nextTrigger(ts(2026,2,28,9,0), "2026-01-31", "08:30", "monthly"), ts(2026,3,31,8,30), "monthly following");
    isTrue(ReminderTime.nextTrigger(ts(2026,10,25,7,0), "bad", "08:30", "once") == -1L, "bad date");
    System.out.println("ReminderTime tests passed");
  }
}
