const assert=require('assert');
const v2=require('../app/src/main/assets/platform_v2.js');
assert.deepStrictEqual(v2.normalizeAmount(2,'كجم'),{dim:'mass',base:2000,label:'جرام'});
assert.deepStrictEqual(v2.normalizeAmount(750,'مللي لتر'),{dim:'volume',base:750,label:'مل'});
assert.equal(v2.plantAgeDays('2026-10-01',new Date(2026,9,26)),25);
assert.equal(v2.mapTotalArea({sectors:[{valves:[{area:2},{area:1.5}]},{valves:[{area:3}]}]}),6.5);
assert.equal(v2.mapValveCount({sectors:[{valves:[{},{}]},{valves:[{}]}]}),3);

const ps=v2.valvePlantingStats({sectors:[{valves:[{plantingDate:'2026-10-01'},{plantingDate:'2026-10-11'},{plantingDate:''}]}]},new Date(2026,9,26));
assert.deepStrictEqual(ps,{total:3,planted:2,unplanted:1,minAge:15,maxAge:25});
console.log('platform_v2_core: PASS');
