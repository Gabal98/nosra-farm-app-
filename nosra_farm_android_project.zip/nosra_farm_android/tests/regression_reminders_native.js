const fs=require('fs');
const scheduler=fs.readFileSync('app/src/main/java/com/nosrafarm/app/ReminderScheduler.java','utf8');
const receiver=fs.readFileSync('app/src/main/java/com/nosrafarm/app/ReminderReceiver.java','utf8');
const boot=fs.readFileSync('app/src/main/java/com/nosrafarm/app/BootReceiver.java','utf8');
const gradle=fs.readFileSync('app/build.gradle.kts','utf8');
function ok(v,m){if(!v){console.error('FAIL:',m);process.exitCode=1}}
ok(scheduler.includes('setAndAllowWhileIdle'),'uses AlarmManager idle-safe scheduling');
ok(scheduler.includes('SharedPreferences'),'stores native reminder schedule');
ok(receiver.includes('NotificationChannel'),'creates notification channel');
ok(receiver.includes('ReminderScheduler.scheduleOne'),'repeating reminder reschedules');
ok(boot.includes('rescheduleStored'),'boot restores alarms');
ok(Number((gradle.match(/versionCode\s*=\s*(\d+)/)||[])[1]||0)>=8,'versionCode bumped');
ok(/versionName\s*=\s*"(?:1\.[5-9]\.\d+|[2-9]\.\d+\.\d+)"/.test(gradle),'versionName bumped');
if(!process.exitCode)console.log('Native reminder source checks passed');
