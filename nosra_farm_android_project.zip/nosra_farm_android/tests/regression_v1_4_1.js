const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('app/src/main/assets/index.html','utf8');
const java = fs.readFileSync('app/src/main/java/com/nosrafarm/app/MainActivity.java','utf8');
const gradle = fs.readFileSync('app/build.gradle.kts','utf8');

assert(html.includes('body.dark .section:not(#printSheet) .export-table td'), 'dark app export-table cells need explicit dark styling');
assert(html.includes('body.dark .section:not(#printSheet) .export-table tbody tr:nth-child(even)'), 'dark app export-table alternating rows need dark styling');
assert(html.includes('#opsTable .export-table{min-width:760px'), 'operations table must keep readable mobile width');
assert(html.includes('.table-scroll{overflow-x:auto'), 'table containers must scroll horizontally');
assert(java.includes('setOnApplyWindowInsetsListener'), 'Android WebView must handle system bar insets');
assert(java.includes('exportBackup(') && java.includes('requestRestoreBackup(') && java.includes('restoreAutoBackup()'), 'backup/restore bridge must remain present');
assert(html.includes('function createFullBackup()') && html.includes('function restoreFullBackup()'), 'backup/restore UI functions must remain present');
const vc=Number((gradle.match(/versionCode\s*=\s*(\d+)/)||[])[1]||0);
assert(vc>=7, 'versionCode must not regress below 7');
assert(/versionName\s*=\s*"(?:1\.(?:4\.[1-9]\d*|[5-9]\.\d+)|[2-9]\.\d+\.\d+)"/.test(gradle), 'versionName must be 1.4.1 or newer');
console.log('regression_v1_4_1: PASS');
