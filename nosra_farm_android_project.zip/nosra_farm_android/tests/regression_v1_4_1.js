const fs = require('fs');
const assert = require('assert');
const html = fs.readFileSync('app/src/main/assets/index.html','utf8');
const java = fs.readFileSync('app/src/main/java/com/nosrafarm/app/MainActivity.java','utf8');
const gradle = fs.readFileSync('app/build.gradle.kts','utf8');

assert(html.includes('body.dark .section:not(#printSheet) .export-table td'), 'dark app export-table cells need explicit dark styling');
assert(html.includes('body.dark .section:not(#printSheet) .export-table tbody tr:nth-child(even)'), 'dark app export-table alternating rows need dark styling');
assert(html.includes('#opsTable .export-table{min-width:760px'), 'operations table must keep readable mobile width');
assert(html.includes('.table-scroll{overflow-x:auto'), 'table containers must scroll horizontally');
assert(java.includes('setOnApplyWindowInsetsListener'), 'Android WebView must handle system bar insets');
assert(java.includes('exportBackup(') && java.includes('requestRestoreBackup(') && java.includes('restoreAutoBackup()'), 'backup/restore bridge must remain present');
assert(html.includes('function createFullBackup()') && html.includes('function restoreFullBackup()'), 'backup/restore UI functions must remain present');
assert(gradle.includes('versionCode = 7'), 'versionCode must increment to 7');
assert(gradle.includes('versionName = "1.4.1"'), 'versionName must be 1.4.1');
console.log('regression_v1_4_1: PASS');
