const fs=require('fs');
const assert=require('assert');
const v2=fs.readFileSync('app/src/main/assets/platform_v2.js','utf8');
const gradle=fs.readFileSync('app/build.gradle.kts','utf8');

assert(!v2.includes('زراعة ${escapeHtml(v.plantingDate)} — عمر ${age} يوم'), 'map cards must not show planting date');
assert(v2.includes("`عمر النبات ${age} يوم`"), 'planted valve card should show plant age only');
assert(v2.includes('function deleteProfile('), 'profiles must support deletion');
assert(v2.includes("V2.deleteProfile('${p.id}')"), 'open profile card must render delete action');
assert(v2.includes("p.status!=='closed'"), 'closed/archive profiles must not expose delete action');
assert(v2.includes('لا يمكن حذف آخر بروفايل'), 'must protect the last remaining profile');
assert(v2.includes('حذف البروفايل'), 'profile deletion must ask for confirmation');
assert(/versionCode\s*=\s*(\d+)/.test(gradle) && Number(RegExp.$1)>=11,'versionCode must be >= 11');
assert(gradle.includes('versionName = "2.1.1"'),'versionName must be 2.1.1');
console.log('regression_v2_1_1_patch: PASS');
