const fs=require('fs');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const manifest=fs.readFileSync('app/src/main/AndroidManifest.xml','utf8');
const main=fs.readFileSync('app/src/main/java/com/nosrafarm/app/MainActivity.java','utf8');
function ok(v,m){if(!v){console.error('FAIL:',m);process.exitCode=1}}
ok(!html.includes('data-sec="reminders"'),'reminders removed from main navigation');
ok(html.includes('id="fertReminderPanel"'),'compact reminders live inside fertilization');
ok(html.includes('farmFertilizerRemindersV1'),'reminders local storage key exists');
ok(html.includes('function syncRemindersNative'),'native sync function exists');
ok(html.includes("repeat:'once'"),'compact reminder is one-time');
ok(html.includes('function completeReminder'),'reminder can be marked done');
ok(manifest.includes('android.permission.POST_NOTIFICATIONS'),'notification permission in manifest');
ok(manifest.includes('.BootReceiver'),'boot receiver in manifest');
ok(main.includes('public void syncReminders(String json)'),'bridge sync exists');
ok(main.includes('public void requestNotificationPermission()'),'bridge permission exists');
if(!process.exitCode)console.log('Reminder regression tests passed');
