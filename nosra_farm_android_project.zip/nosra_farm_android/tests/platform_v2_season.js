const assert=require('assert');
class LS{constructor(){this.m=new Map()}get length(){return this.m.size}key(i){return [...this.m.keys()][i]??null}getItem(k){return this.m.has(k)?this.m.get(k):null}setItem(k,v){this.m.set(k,String(v))}removeItem(k){this.m.delete(k)}clear(){this.m.clear()}}
global.localStorage=new LS();global.location={reload(){}};
require('../app/src/main/assets/platform_v2.js');
global.laborConfig={contractors:['مقاول أ'],columns:['عدد العمالة','جمع','رش'],days:{'2026-10-01':{'0-0':10,'0-1':8,'0-2':2}},dayRates:{'2026-10-01':{'0':100}}};
const l=global.V2.laborSeasonSummary();
assert.equal(l.workerDays,10);assert.equal(l.totalCost,1000);assert.equal(l.operations['جمع'].cost,800);assert.equal(l.operations['رش'].cost,200);
global.harvestV2={types:[{id:'export',name:'تصدير',factor:2}],days:{'2026-10-01':{items:{export:{count:100,manualWeight:false,weight:0}}}},loading:{}};
const h=global.V2.harvestSeasonSummary();assert.equal(h.boxes,100);assert.equal(h.kg,200);assert.equal(h.days,1);
console.log('platform_v2_season: PASS');
