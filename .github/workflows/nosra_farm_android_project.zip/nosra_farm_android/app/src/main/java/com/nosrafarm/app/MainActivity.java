package com.nosrafarm.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.net.Uri;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.io.ByteArrayOutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23,77,55));

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printDocument() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("تقرير مزرعة نصرة");
                pm.print("تقرير مزرعة نصرة", adapter, new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void savePng(String base64, String fileName) {
            try {
                Uri uri = writePng(base64, fileName);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "تم حفظ الصورة في الصور", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "فشل حفظ الصورة: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void sharePng(String base64, String fileName) {
            try {
                Uri uri = writePng(base64, fileName);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(send, "مشاركة التقرير")));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "فشل مشاركة الصورة: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public void captureReportPng(String fileName, boolean share) {
            runOnUiThread(() -> {
                try {
                    Picture picture = webView.capturePicture();
                    if (picture == null || picture.getWidth() <= 0 || picture.getHeight() <= 0) {
                        throw new IllegalStateException("تعذر التقاط التقرير");
                    }
                    Bitmap bitmap = Bitmap.createBitmap(picture.getWidth(), picture.getHeight(), Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    canvas.drawColor(Color.WHITE);
                    picture.draw(canvas);

                    ByteArrayOutputStream buffer = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, buffer);
                    bitmap.recycle();
                    Uri uri = writePngBytes(buffer.toByteArray(), fileName);

                    if (share) {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/png");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "مشاركة التقرير"));
                    } else {
                        Toast.makeText(MainActivity.this, "تم حفظ صورة التقرير في الصور", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "فشل إنشاء صورة التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    webView.evaluateJavascript("window.onNativeCaptureDone && window.onNativeCaptureDone()", null);
                }
            });
        }

        private Uri writePng(String b64, String fileName) throws Exception {
            return writePngBytes(Base64.decode(b64, Base64.DEFAULT), fileName);
        }

        private Uri writePngBytes(byte[] data, String fileName) throws Exception {
            String safeName = (fileName == null || fileName.trim().isEmpty()) ? "NosraFarmReport.png" : fileName;
            if (!safeName.toLowerCase().endsWith(".png")) safeName += ".png";

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NosraFarm");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);

            ContentResolver resolver = getContentResolver();
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("تعذر إنشاء ملف الصورة");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IllegalStateException("تعذر فتح ملف الصورة");
                out.write(data);
                out.flush();
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return uri;
        }
    }
}
